// MyDll.h : main header file for the MYDLL DLL
//

#if !defined(AFX_MYDLL_H__1FAFEE59_88D6_11D6_89D7_00010302158B__INCLUDED_)
#define AFX_MYDLL_H__1FAFEE59_88D6_11D6_89D7_00010302158B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CMyDllApp
// See MyDll.cpp for the implementation of this class
//

class CMyDllApp : public CWinApp
{
public:
	CMyDllApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMyDllApp)
	//}}AFX_VIRTUAL

	//{{AFX_MSG(CMyDllApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MYDLL_H__1FAFEE59_88D6_11D6_89D7_00010302158B__INCLUDED_)
